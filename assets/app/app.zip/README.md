# app
Dxs app template for FletEasy

# 🔥A Flet application with the [`Flet-Easy`](https://github.com/Daxexs/flet-easy) plugin.
An example of a minimal Flet application.

🗂️ Folder = app

To run the application:
```bash
flet run app/main.py.
```